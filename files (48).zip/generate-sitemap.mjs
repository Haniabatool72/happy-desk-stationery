// Happy Desk — makes sitemap.xml + robots.txt from your live Supabase products.
// Run after adding products (needs Node 18+):   node generate-sitemap.mjs https://your-site.com
// Then upload the two new files (sitemap.xml, robots.txt) next to index.html.
import { readFileSync, writeFileSync } from 'node:fs';

const site = (process.argv[2] || '').replace(/\/+$/, '');
if (!/^https?:\/\//.test(site)) { console.error('Usage: node generate-sitemap.mjs https://your-site.com'); process.exit(1); }

const html = readFileSync(new URL('./index.html', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'), 'utf8');
const url = (html.match(/url:\s*'(https:\/\/[^']+\.supabase\.co)'/) || [])[1];
const key = (html.match(/anonKey:\s*'([^']+)'/) || [])[1];
if (!url || !key) { console.error('Could not find the Supabase url / anonKey inside index.html'); process.exit(1); }

const slug = n => n.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
let products = [];
for (let f = 0; ; f += 1000) {
  const res = await fetch(`${url}/rest/v1/products?select=name,kind&active=eq.true&order=name&limit=1000&offset=${f}`, { headers: { apikey: key, Authorization: `Bearer ${key}` } });
  if (!res.ok) { console.error('Supabase error', res.status, await res.text()); process.exit(1); }
  const part = await res.json(); products = products.concat(part); if (part.length < 1000) break;
}

const catSlugs = [...html.matchAll(/slug:\s*["']([a-z0-9-]+)["']/g)].map(m => m[1]);
const today = new Date().toISOString().slice(0, 10);
const pages = [['/', 1.0], ['/stationery', .9], ['/toys', .9], ['/gallery', .5],
  ...[...new Set(catSlugs)].map(c => ['/category/' + c, .8]),
  ...products.map(p => [`/product/${slug(p.name)}`, .7]).filter(([u]) => u !== '/product/')];

const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
  pages.map(([u, pr]) => `  <url><loc>${site}${u === '/' ? '/' : u}</loc><lastmod>${today}</lastmod><priority>${pr.toFixed(1)}</priority></url>`).join('\n') + '\n</urlset>\n';
writeFileSync('sitemap.xml', xml);
writeFileSync('robots.txt', `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /counter\nDisallow: /cart\nDisallow: /checkout\nDisallow: /order\nDisallow: /track\n\nSitemap: ${site}/sitemap.xml\n`);
console.log(`Done: sitemap.xml with ${pages.length} pages + robots.txt`);
